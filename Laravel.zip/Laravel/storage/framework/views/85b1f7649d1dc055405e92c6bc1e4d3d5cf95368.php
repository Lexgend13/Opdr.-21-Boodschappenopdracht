

<?php $__env->startSection('title'); ?>
    <title>Add groceries</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('groceries.store')); ?>"> 
        <?php echo csrf_field(); ?>
        <label for='product'>
            Product
        </label>
        <br>
        <input 
            type="text"
            name="product"
            id="product"
            value="<?php echo e(old('product')); ?>"
            required
        >
        <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <div>
            Category
        </div>
        <select name="category_id">
           
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <br>
        <label for='quantity'>
            Quantity
        </label>
        <br>
        <input 
            type='text'
            name='quantity'
            id='quantity'
            value="<?php echo e(old('quantity')); ?>"
            required
        >
        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <label for='price'>
            Price
        </label>
        <br>
        <input 
            type='text'
            name='price'
            id='price'
            value="<?php echo e(old('price')); ?>"
            required
        >
        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <button type="submit">
            Submit all
        </button>
        </form>
    <br>
    <button type="reset">
        Reset inputs
    </button>
    <br>
    <br>
    <div>Field suggestions</div>
    <button onclick="keepInput()">
        On
    </button>
    <button onclick="clearInput()">
        Off
    </button>
        <script>
            function clearInput () {
                document.getElementById("price").setAttribute("autocomplete", "off");
                document.getElementById("quantity").setAttribute("autocomplete", "off");
            }
            function keepInput () {
                document.getElementById("price").setAttribute("autocomplete", "on");
                document.getElementById("quantity").setAttribute("autocomplete", "on");
            }
        </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lex de Grave\Documents\Script\Opdr. 21; Boodschappenopdracht\Laravel\resources\views/groceries/create.blade.php ENDPATH**/ ?>