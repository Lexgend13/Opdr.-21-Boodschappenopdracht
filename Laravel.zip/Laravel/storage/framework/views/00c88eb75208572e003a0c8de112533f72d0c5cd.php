<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->yieldContent('title'); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
<ul>
        <li><a href="<?php echo e(route('groceries.index')); ?>">Groceries</a></li>
        <li><a href="<?php echo e(route('groceries.create')); ?>">Create</a></li>
    </ul>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\Lex de Grave\Documents\Script\Opdr. 21; Boodschappenopdracht\Laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>