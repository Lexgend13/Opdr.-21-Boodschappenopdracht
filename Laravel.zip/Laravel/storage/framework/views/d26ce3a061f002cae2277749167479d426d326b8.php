

<?php $__env->startSection('title'); ?>
    <title>Laravel boodschappenlijst</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .right {
            text-align: right;
            width: 75px;
        }

        .product {
            width: 240px;
        }

        .th {
            text-align: left;
        }

        .hide
        {
            border: none;
        }

        .category {
            width: 139px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table border='1'>
        <thead>
            <tr>
                <th id='product'>Product</th>
                <th class='category'>Category</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total price</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $sum = 0; ?>
            <?php foreach($groceries as $grocery): ?>
                <tr>
                    <td class='product'><?php echo e($grocery->product); ?></td>
                    <td class='right'><?php echo e($grocery->category->category); ?></td>
                    <td class='right'><?php echo e(number_format($grocery->price,2)); ?></td>
                    <td class='right'><?php echo e($grocery->quantity); ?></td>
                    <td class='right'><?php echo e(number_format($grocery->price * $grocery->quantity,2)); ?></td>
                    <td class='hide'><a href="<?php echo e(route('groceries.edit', ['grocery' => $grocery->id])); ?>">Edit</td>
                    <td class='hide'>
                        <form method='POST' action="<?php echo e(route('groceries.destroy', ['grocery' => $grocery->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button>Delete</button>
                        </form>
                    </td>
                </tr>
                <?php $sum += $grocery->price * $grocery->quantity; ?>
            <?php endforeach; ?>
                <tr>
                    <td class='hide'></td>
                    <td class='hide'></td>
                    <td colspan='2'><strong>Total Price</strong></td>
                    <td class='right'><strong><?php echo e(number_format($sum,2)); ?></strong></td>
                </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lex de Grave\Documents\Script\Opdr. 21; Boodschappenopdracht\Laravel\resources\views/groceries/index.blade.php ENDPATH**/ ?>